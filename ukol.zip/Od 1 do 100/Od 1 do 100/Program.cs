﻿//Úkol č.1
for (int i = 0; i <= 100; i++)
{
	if (i == 40 || i == 60)
	{
		continue;
	}
	Console.WriteLine(i);
}

//Úkol č.2

Console.WriteLine("**************");
Console.WriteLine("*            *");
Console.WriteLine("*            *");
Console.WriteLine("*            *");
Console.WriteLine("*            *");
Console.WriteLine("**************");


//Úkol č.3


int pocitadlo = 0;
int cislo = -1;



while (cislo != 0)
{
	pocitadlo++;
    cislo = int.Parse(Console.ReadLine());
}

Console.WriteLine("Počet zadaných čísel: " + (pocitadlo - 1));